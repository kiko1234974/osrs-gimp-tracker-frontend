
const WIDGET_LIST =
{
    TL_BORDER: 0,
    TR_BORDER: 1,
    BL_BORDER: 2,
    BR_BORDER: 3,

    HORIZONTAL_BORDER: 4,
    VERTICAL_BORDER: 5,

    UP_SCROLL_BUTTON: 6,
    DOWN_SCROLL_BUTTON: 7,

    SCROLL_BACKGROUND: 8,
    SCROLL_INDICATOR_TOP: 9,
    SCROLL_INDICATOR_BOTTOM: 10,
    SCROLL_INDICATOR_MIDDLE: 11,
    
    MAX: 4,
}

const WIDGET_LIST_TEXTURES =
[
    '777-0.png',
    '222-0.png',
    '778-0.png',
    '908-0.png',
]

class WidgetList
{
    constructor(width, height)
    {

    }

    addHeader(text)
    {

    }

    addItem(text)
    {

    }
}
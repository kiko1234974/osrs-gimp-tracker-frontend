import { HudObject } from "../object.js";

export class Interface extends HudObject
{
    constructor(name)
    {
        super(name);
    }

    init()
    {
        
    }

    onAssetsLoaded()
    {
        
    }
}